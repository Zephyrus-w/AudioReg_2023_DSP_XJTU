import os
import numpy as np
import pandas as pd
import json
from scipy.spatial.distance import euclidean

'''
data_hanning_path = os.path.join(os.path.dirname(__file__), '..', 'time_hanning_eigenvector')
hanning_vectors_path = os.path.abspath(data_hanning_path)
data_hamming_path = os.path.join(os.path.dirname(__file__), '..', 'time_hamming_eigenvector')
hamming_vectors_path = os.path.abspath(data_hamming_path)


with open(hanning_vectors_path, 'r') as file:
    data_hanning = json.load(file)
with open(hamming_vectors_path,'r') as file:
    data_hamming = json.load(file)
'''
import numpy as np

def dtw_distance(sequence1, sequence2):
    n, m = len(sequence1), len(sequence2)
    dtw_matrix = np.zeros((n+1, m+1))

    for i in range(1, n+1):
        dtw_matrix[i, 0] = np.inf
    for i in range(1, m+1):
        dtw_matrix[0, i] = np.inf

    dtw_matrix[0, 0] = 0

    for i in range(1, n+1):
        for j in range(1, m+1):
            cost = abs(sequence1[i-1] - sequence2[j-1])
            last_min = min(dtw_matrix[i-1, j], dtw_matrix[i, j-1], dtw_matrix[i-1, j-1])
            dtw_matrix[i, j] = cost + last_min

    return dtw_matrix[n, m]


def x_y_loader(data):
    # 假设 data 是一个10x17的列表，每个元素是一个一维特征向量列表
    num_digits = 10
    num_speakers = 17

    X = []  # 特征数据
    y = []  # 标签数据

    for digit in range(num_digits):
        for speaker in range(num_speakers):
            X.append(data[digit][speaker])
            y.append(digit)

    return X, y